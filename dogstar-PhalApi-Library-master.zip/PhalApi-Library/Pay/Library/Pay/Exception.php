<?php

class Pay_Exception extends PhalApi_Exception_InternalServerError {

}
