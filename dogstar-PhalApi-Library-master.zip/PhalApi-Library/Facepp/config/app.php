<?php

return [
    //请将以下配置拷贝到 ./Config/app.php 文件对应的位置中
    'Facepp'=>array(
        'api_key'=>'your api_key',
        'api_secret'=>'your api_secret',
    )
];


