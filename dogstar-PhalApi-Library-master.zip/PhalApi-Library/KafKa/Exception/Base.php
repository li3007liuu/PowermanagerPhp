<?php

/**
 * KafKa-Exception 异常类
 * @author : @喵了个咪<wenzhenxi@vip.qq.com>
 */
class KafKa_Exception_Base extends Exception {

}
