<?php
/**
 * 翻译说明：
 *
 * 1、带大括号的保留原来写法，如：{name}，会被系统动态替换
 * 2、没在以下出现的，可以自行追加
 *
 * @author dogstar <chanzonghuang@gmail.com> 2015-02-09
 */

return array(
	'DE_WELCOME' => '{0}您好，欢迎使用FreeApi！',
    'NOT_EXISTS' => '{0}不存在',
    'PARAMS_ERROR' => '参数错误'
);
