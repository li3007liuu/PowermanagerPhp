<?php

return array(
    'DE_WELCOME' => 'Hello {0}, Welcome to use FreeApi！',
    'NOT_EXISTS' => '{0} not exists',
    'PARAMS_ERROR' => 'Parameter error'
);
