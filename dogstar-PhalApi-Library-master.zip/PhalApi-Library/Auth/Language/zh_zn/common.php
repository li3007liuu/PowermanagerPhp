<?php

/**
 * 翻译说明：
 *
 * 1、带大括号的保留原来写法，如：{name}，会被系统动态替换
 * 2、没在以下出现的，可以自行追加
 *
 * @author dogstar <chanzonghuang@gmail.com> 2015-02-09
 */
return array(
    'success' => '操作成功',
    'failed' => '操作失败',
    'data get failed' => '数据获取失败',
    'group name repeat' => '组名称重复',
    'rule name repeat' => '规则标识重复',
);
