<?php

interface FastRoute_Handler {

	public function excute(PhalApi_Response $response);
}
