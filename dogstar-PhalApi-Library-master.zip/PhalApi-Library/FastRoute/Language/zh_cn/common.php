<?php
/**
 * 翻译说明：
 *
 * 1、带大括号的保留原来写法，如：{name}，会被系统动态替换
 * 2、没在以下出现的，可以自行追加
 *
 * @author dogstar <chanzonghuang@gmail.com> 2015-02-09
 */

return array(
    'FastRoute Method Not Allowed, It Should be: {methods}' => '快速路由的HTTP请求方法错误，应该为：{methods}',
);
