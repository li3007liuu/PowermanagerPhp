<?php

return array(
    'CryptTraffic' => array(
        'hashParam' =>'hashdata', //用来传递加密数据的参数名
        'responseParam' => 'data', //加密返回值参数名
    ),

);


